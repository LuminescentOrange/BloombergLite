from asyncore import write
from itertools import count
import pandas as pd


data = pd.read_csv(r"C:\\Users\\liiff\\Desktop\\NASDAQ.csv", index_col=0)
data = data.drop(['Last Sale','Net Change','% Change','Market Cap','Country','IPO Year','Volume'],axis=1) 
data = data[data['Sector'].notna()]
data = data[data['Industry'].notna()]


count = data[u'Industry'].value_counts()
count.to_csv('./count.csv',encoding='utf-8-sig')
data.to_csv('data.csv', encoding='utf-8-sig')


