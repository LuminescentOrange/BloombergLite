import requests
from bs4 import BeautifulSoup
import xlwt

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInHHIDExperiment': 'false',
    'isInAuthTokenExperiment': 'true',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfBE4BzSpgAiuEABoQwmCDJU6jZjOIgAvkA',
    '_sp_ses.f5fb': '*',
    '_bts': '16d2d3b2-3a02-4134-e984-a94241195bd9',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D5%7C176917733%3D5',
    'mnjs_session_depth': '3%7C1649212456665',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649212798.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fcommunications%2F',
    's_sq': '%5B%5BB%5D%5D',
    '_chartbeat2': '.1649184641023.1649212799158.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.16',
    '_chartbeat5': '',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+21%3A39%3A59+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'gNeuoF9FVXRlcVIxZnJabThIeFRQVjYxck1BeU00eG1xcVFCQ0pWUkZQb1ljN2QlMkJtSHJSJTJGSFZFV3dlYzNDMzJYV3paOXI5QyUyRk0lMkIyb0JFZVBFaHJlcE5hYiUyRmJ5WHlZdUZ6SFR0bFlIcnAwdXBVY1ZrbnFJYlJUUWF6enB3VVdPRGFDcEx5YSUyQnMxWFNScmd3aEFxTjRlWGxINFElM0QlM0Q',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/tech/communications/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInHHIDExperiment=false; isInAuthTokenExperiment=true; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfBE4BzSpgAiuEABoQwmCDJU6jZjOIgAvkA; _sp_ses.f5fb=*; _bts=16d2d3b2-3a02-4134-e984-a94241195bd9; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D5%7C176917733%3D5; mnjs_session_depth=3%7C1649212456665; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649212798.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fcommunications%2F; s_sq=%5B%5BB%5D%5D; _chartbeat2=.1649184641023.1649212799158.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.16; _chartbeat5=; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+21%3A39%3A59+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=gNeuoF9FVXRlcVIxZnJabThIeFRQVjYxck1BeU00eG1xcVFCQ0pWUkZQb1ljN2QlMkJtSHJSJTJGSFZFV3dlYzNDMzJYV3paOXI5QyUyRk0lMkIyb0JFZVBFaHJlcE5hYiUyRmJ5WHlZdUZ6SFR0bFlIcnAwdXBVY1ZrbnFJYlJUUWF6enB3VVdPRGFDcEx5YSUyQnMxWFNScmd3aEFxTjRlWGxINFElM0QlM0Q',
}

params = {
    'sector': '4900',
    'industry': 'Industries within Communications',
}

response = requests.get('https://money.cnn.com/data/sectors/tech/communications/', headers=headers, params=params, cookies=cookies)  
fo = open("./communications.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInHHIDExperiment': 'false',
    'isInAuthTokenExperiment': 'true',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bts': '16d2d3b2-3a02-4134-e984-a94241195bd9',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D5%7C176917733%3D5',
    'mnjs_session_depth': '3%7C1649212456665',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649212798.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fcommunications%2F',
    'cto_bundle': 'gNeuoF9FVXRlcVIxZnJabThIeFRQVjYxck1BeU00eG1xcVFCQ0pWUkZQb1ljN2QlMkJtSHJSJTJGSFZFV3dlYzNDMzJYV3paOXI5QyUyRk0lMkIyb0JFZVBFaHJlcE5hYiUyRmJ5WHlZdUZ6SFR0bFlIcnAwdXBVY1ZrbnFJYlJUUWF6enB3VVdPRGFDcEx5YSUyQnMxWFNScmd3aEFxTjRlWGxINFElM0QlM0Q',
    '_chartbeat2': '.1649184641023.1649212804620.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.17',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+21%3A40%3A04+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Fcommunications%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/tech/communications/?sector=4900&industry=Industries%20within%20Communications',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInHHIDExperiment=false; isInAuthTokenExperiment=true; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bts=16d2d3b2-3a02-4134-e984-a94241195bd9; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D5%7C176917733%3D5; mnjs_session_depth=3%7C1649212456665; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649212798.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fcommunications%2F; cto_bundle=gNeuoF9FVXRlcVIxZnJabThIeFRQVjYxck1BeU00eG1xcVFCQ0pWUkZQb1ljN2QlMkJtSHJSJTJGSFZFV3dlYzNDMzJYV3paOXI5QyUyRk0lMkIyb0JFZVBFaHJlcE5hYiUyRmJ5WHlZdUZ6SFR0bFlIcnAwdXBVY1ZrbnFJYlJUUWF6enB3VVdPRGFDcEx5YSUyQnMxWFNScmd3aEFxTjRlWGxINFElM0QlM0Q; _chartbeat2=.1649184641023.1649212804620.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.17; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+21%3A40%3A04+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Fcommunications%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'sector': '4900',
    'industry': 'Industries within Communications',
    'page': '2',
}

response = requests.get('https://money.cnn.com/data/sectors/tech/communications/?sector=4900&industry=Industries%20within%20Communications&page=2', headers=headers, params=params, cookies=cookies)
fo = open("./communications.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()


cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bts': '16d2d3b2-3a02-4134-e984-a94241195bd9',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649212798.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxCAAvkA',
    'session_depth': 'money.cnn.com%3D6%7C176917733%3D6',
    'mnjs_session_depth': '4%7C1649212456665',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fconsumer_durables%2F',
    's_sq': '%5B%5BB%5D%5D',
    '_chartbeat2': '.1649184641023.1649213297001.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.23',
    '_chartbeat5': '',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+21%3A48%3A17+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'pXTyll9FVXRlcVIxZnJabThIeFRQVjYxck1OUkZvbzVuNVpWJTJCSjNuTFA1WmN5VXJSQ1NxbnFrTlpHQ3liNngxRUkwTmhWSDNLZllvdGtPWEwxNXhkQ21mSUpYMlFleWJMdWZQZ2k3VXp3RHE4enpVTWpUSlg2ZndHOWdaOVZidm9LUmI5U2RId3dMb2xLYmJwUzFsZFElMkIlMkJFc2clM0QlM0Q',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/consumer_durables/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bts=16d2d3b2-3a02-4134-e984-a94241195bd9; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649212798.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxCAAvkA; session_depth=money.cnn.com%3D6%7C176917733%3D6; mnjs_session_depth=4%7C1649212456665; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fconsumer_durables%2F; s_sq=%5B%5BB%5D%5D; _chartbeat2=.1649184641023.1649213297001.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.23; _chartbeat5=; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+21%3A48%3A17+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=pXTyll9FVXRlcVIxZnJabThIeFRQVjYxck1OUkZvbzVuNVpWJTJCSjNuTFA1WmN5VXJSQ1NxbnFrTlpHQ3liNngxRUkwTmhWSDNLZllvdGtPWEwxNXhkQ21mSUpYMlFleWJMdWZQZ2k3VXp3RHE4enpVTWpUSlg2ZndHOWdaOVZidm9LUmI5U2RId3dMb2xLYmJwUzFsZFElMkIlMkJFc2clM0QlM0Q',
}

params = {
    'sector': '1400',
    'industry': 'Industries within Consumer Durables',
}

response = requests.get('https://money.cnn.com/data/sectors/consumer_durables/', headers=headers, params=params, cookies=cookies)
fo = open("./consumer durables.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bts': '16d2d3b2-3a02-4134-e984-a94241195bd9',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D8%7C176917733%3D8',
    'mnjs_session_depth': '2%7C1649213387684',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649214147.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fconsumer_nondurables%2F',
    's_sq': '%5B%5BB%5D%5D',
    '_chartbeat2': '.1649184641023.1649214477549.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.45',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A07%3A57+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': '6JTRVl9FVXRlcVIxZnJabThIeFRQVjYxck1PdnN6JTJCUmFIJTJCOFprJTJCN2J0VG9XNHJTODQ0YTZhMW9aazZ5TlJiSzZGUTV6NElYaWZDV2Y5NkVQUVIwWTIwMyUyRnB3UFF6WW1VRWViZ3Z4Q2xoODZ0ZU9ONk1ib2hwYmMlMkZJb2RPV05hTnlQJTJGdENGemUxcWk0WEI0JTJCVGdYcVRHJTJCNUZBJTNEJTNE',
}

headers = {
    'authority': 'money.cnn.com',
    'cache-control': 'max-age=0',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/consumer_nondurables/?sector=2400&industry=Industries%20within%20Consumer%20Non-Durables&page=2',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bts=16d2d3b2-3a02-4134-e984-a94241195bd9; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D8%7C176917733%3D8; mnjs_session_depth=2%7C1649213387684; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649214147.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fconsumer_nondurables%2F; s_sq=%5B%5BB%5D%5D; _chartbeat2=.1649184641023.1649214477549.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.45; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A07%3A57+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=6JTRVl9FVXRlcVIxZnJabThIeFRQVjYxck1PdnN6JTJCUmFIJTJCOFprJTJCN2J0VG9XNHJTODQ0YTZhMW9aazZ5TlJiSzZGUTV6NElYaWZDV2Y5NkVQUVIwWTIwMyUyRnB3UFF6WW1VRWViZ3Z4Q2xoODZ0ZU9ONk1ib2hwYmMlMkZJb2RPV05hTnlQJTJGdENGemUxcWk0WEI0JTJCVGdYcVRHJTJCNUZBJTNEJTNE',
}

params = {
    'sector': '2400',
    'industry': 'Industries within Consumer Non-Durables',
    'page': '1',
}

response = requests.get('https://money.cnn.com/data/sectors/consumer_nondurables/', headers=headers, params=params, cookies=cookies)
fo = open("./consumer non-durables.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bts': '16d2d3b2-3a02-4134-e984-a94241195bd9',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxCAAvkA',
    'session_depth': 'money.cnn.com%3D8%7C176917733%3D8',
    'mnjs_session_depth': '2%7C1649213387684',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649213495.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fconsumer_nondurables%2F',
    's_sq': '%5B%5BB%5D%5D',
    '_chartbeat2': '.1649184641023.1649213826480.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.39',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+21%3A57%3A06+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'RZlNel9FVXRlcVIxZnJabThIeFRQVjYxck1JUzFGTmhhTXNLRHZmTUxTbWNod2JlUlNjbTRlbmVlJTJCRmI2S2x6WGloNFVSZHhvYllnZnBtdDYzMzc5Um1OalhzeVU3TzRwSjUzb2lxcSUyQmtJV0pSajdQVFcySThDb01kMTFVbVZvOEVOeVZVemFUelhtYjklMkIzcUsxOVR0Z0dmMFElM0QlM0Q',
}

headers = {
    'authority': 'money.cnn.com',
    'cache-control': 'max-age=0',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/consumer_nondurables/?sector=2400&industry=Industries%20within%20Consumer%20Non-Durables&page=1',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bts=16d2d3b2-3a02-4134-e984-a94241195bd9; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxCAAvkA; session_depth=money.cnn.com%3D8%7C176917733%3D8; mnjs_session_depth=2%7C1649213387684; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649213495.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fconsumer_nondurables%2F; s_sq=%5B%5BB%5D%5D; _chartbeat2=.1649184641023.1649213826480.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.39; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+21%3A57%3A06+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=RZlNel9FVXRlcVIxZnJabThIeFRQVjYxck1JUzFGTmhhTXNLRHZmTUxTbWNod2JlUlNjbTRlbmVlJTJCRmI2S2x6WGloNFVSZHhvYllnZnBtdDYzMzc5Um1OalhzeVU3TzRwSjUzb2lxcSUyQmtJV0pSajdQVFcySThDb01kMTFVbVZvOEVOeVZVemFUelhtYjklMkIzcUsxOVR0Z0dmMFElM0QlM0Q',
}

params = {
    'sector': '2400',
    'industry': 'Industries within Consumer Non-Durables',
    'page': '2',
}

response = requests.get('https://money.cnn.com/data/sectors/consumer_nondurables/?sector=2400&industry=Industries%20within%20Consumer%20Non-Durables&page=2', headers=headers, params=params, cookies=cookies)
fo = open("./consumer non-durables.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInHHIDExperiment': 'false',
    'isInAuthTokenExperiment': 'true',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D8%7C176917733%3D8',
    'mnjs_session_depth': '2%7C1649213387684',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649214147.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fconsumer_nondurables%2F',
    's_sq': '%5B%5BB%5D%5D',
    '_chartbeat2': '.1649184641023.1649214737388.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.48',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A12%3A17+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'SfqaEl9FVXRlcVIxZnJabThIeFRQVjYxck1EMTF2czFOeWhnTyUyRjBtaHQlMkJvYW9ZdVUzV3dGZDFnVmVEb0NlVGRjJTJCVFdBdjBzU0UzYTB1SUwyYmtreVFuQmdGSXRKd2VoU2x2VlJRMHBDNHNOYjNZWmFYTWdLSzg2b3NtbUJMSUpETlhjMlNjdm81NnREY2tSN0xpQ0lmNmFKQlElM0QlM0Q',
}

headers = {
    'authority': 'money.cnn.com',
    'cache-control': 'max-age=0',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/consumer_nondurables/?sector=2400&industry=Industries%20within%20Consumer%20Non-Durables&page=2',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInHHIDExperiment=false; isInAuthTokenExperiment=true; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D8%7C176917733%3D8; mnjs_session_depth=2%7C1649213387684; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649214147.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fconsumer_nondurables%2F; s_sq=%5B%5BB%5D%5D; _chartbeat2=.1649184641023.1649214737388.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.48; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A12%3A17+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=SfqaEl9FVXRlcVIxZnJabThIeFRQVjYxck1EMTF2czFOeWhnTyUyRjBtaHQlMkJvYW9ZdVUzV3dGZDFnVmVEb0NlVGRjJTJCVFdBdjBzU0UzYTB1SUwyYmtreVFuQmdGSXRKd2VoU2x2VlJRMHBDNHNOYjNZWmFYTWdLSzg2b3NtbUJMSUpETlhjMlNjdm81NnREY2tSN0xpQ0lmNmFKQlElM0QlM0Q',
}

params = {
    'sector': '2400',
    'industry': 'Industries within Consumer Non-Durables',
    'page': '3',
}

response = requests.get('https://money.cnn.com/data/sectors/consumer_nondurables/?sector=2400&industry=Industries%20within%20Consumer%20Non-Durables&page=3', headers=headers, params=params, cookies=cookies)
fo = open("./consumer non-durables.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA',
    'session_depth': 'money.cnn.com%3D9%7C176917733%3D9',
    'mnjs_session_depth': '1%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649214861.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fcommercial_services%2F',
    's_sq': '%5B%5BB%5D%5D',
    '_chartbeat2': '.1649184641023.1649214862710.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.64',
    '_chartbeat5': '',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A14%3A22+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'EaOQ219FVXRlcVIxZnJabThIeFRQVjYxck1LNUU5UjBUQkRqNWkyMWoxN1BTNHMlMkIlMkZHNkhCVWY1VW4xVHlYQVJYRENlWlZpS3dpdEc1T05zZWliQXhRWVNXckhJTU9EVkZjVzY3UWZlemZIOXhyc3U1dEx1Wk1FaFM5d25SYmNGdGJSd1VQemM1SmpsQSUyQjA4Y1VYRWUyZWZNSEElM0QlM0Q',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/commercial_services/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA; session_depth=money.cnn.com%3D9%7C176917733%3D9; mnjs_session_depth=1%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649214861.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fcommercial_services%2F; s_sq=%5B%5BB%5D%5D; _chartbeat2=.1649184641023.1649214862710.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.64; _chartbeat5=; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A14%3A22+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=EaOQ219FVXRlcVIxZnJabThIeFRQVjYxck1LNUU5UjBUQkRqNWkyMWoxN1BTNHMlMkIlMkZHNkhCVWY1VW4xVHlYQVJYRENlWlZpS3dpdEc1T05zZWliQXhRWVNXckhJTU9EVkZjVzY3UWZlemZIOXhyc3U1dEx1Wk1FaFM5d25SYmNGdGJSd1VQemM1SmpsQSUyQjA4Y1VYRWUyZWZNSEElM0QlM0Q',
}

params = {
    'sector': '3200',
    'industry': 'Industries within Commercial Services',
}

response = requests.get('https://money.cnn.com/data/sectors/commercial_services/', headers=headers, params=params, cookies=cookies)
fo = open("./commercial service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmPageLoadId': '1',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    '_chartbeat5': '',
    's_sq': '%5B%5BB%5D%5D',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fcommercial_services%2F',
    '_chartbeat2': '.1649184641023.1649215160062.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.81',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A19%3A20+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'QowOAl9FVXRlcVIxZnJabThIeFRQVjYxck1JaExtWW9hVlg5QmR1d1Y5QzJyRzY1ZDFiaWdGOGZkWkZkM29ranR0TjhiVG9JcSUyRllMdzZmeFNFdHU0M0VuZWxjWWcwdEltUHoxVkQlMkZmdWtWVzhoNEpRQmclMkJVQTlLbGRDU0oxc3c2MDZ0c0JKUGNTUm9IQmZTdkxhaFRSb2NlWmclM0QlM0Q',
}

headers = {
    'authority': 'money.cnn.com',
    'cache-control': 'max-age=0',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'none',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmPageLoadId=1; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; _chartbeat5=; s_sq=%5B%5BB%5D%5D; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fcommercial_services%2F; _chartbeat2=.1649184641023.1649215160062.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.81; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A19%3A20+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=QowOAl9FVXRlcVIxZnJabThIeFRQVjYxck1JaExtWW9hVlg5QmR1d1Y5QzJyRzY1ZDFiaWdGOGZkWkZkM29ranR0TjhiVG9JcSUyRllMdzZmeFNFdHU0M0VuZWxjWWcwdEltUHoxVkQlMkZmdWtWVzhoNEpRQmclMkJVQTlLbGRDU0oxc3c2MDZ0c0JKUGNTUm9IQmZTdkxhaFRSb2NlWmclM0QlM0Q',
}

params = {
    'page': '2',
}

response = requests.get('https://money.cnn.com/data/sectors/commercial_services/?page=2', headers=headers, params=params, cookies=cookies)
fo = open("./commercial service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInHHIDExperiment': 'false',
    'isInAuthTokenExperiment': 'true',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fcommercial_services%2F',
    's_sq': '%5B%5BB%5D%5D',
    '_chartbeat2': '.1649184641023.1649215619402.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.100',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A26%3A59+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'HXuTl19FVXRlcVIxZnJabThIeFRQVjYxck1EODVNYkFVNVl0dnZCS2VaZHVCT2dpUHpDVXJmaGdnWG9reFplV05ZN1VDSkZYcmNqS3RiJTJCYnhOWFlnbDhoRzV6USUyQkpEQk9WSWlBYWxodFk4VVh2MEh1cEFtJTJCSkx1NDJJcFFyNzJzd0J0WndEaGhlUnA5S2Z3cE5PckZ0eFBXc2clM0QlM0Q',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'none',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInHHIDExperiment=false; isInAuthTokenExperiment=true; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fcommercial_services%2F; s_sq=%5B%5BB%5D%5D; _chartbeat2=.1649184641023.1649215619402.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.100; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A26%3A59+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=HXuTl19FVXRlcVIxZnJabThIeFRQVjYxck1EODVNYkFVNVl0dnZCS2VaZHVCT2dpUHpDVXJmaGdnWG9reFplV05ZN1VDSkZYcmNqS3RiJTJCYnhOWFlnbDhoRzV6USUyQkpEQk9WSWlBYWxodFk4VVh2MEh1cEFtJTJCSkx1NDJJcFFyNzJzd0J0WndEaGhlUnA5S2Z3cE5PckZ0eFBXc2clM0QlM0Q',
}

params = {
    'page': '3',
}

response = requests.get('https://money.cnn.com/data/sectors/commercial_services/?page=3', headers=headers, params=params, cookies=cookies)
fo = open("./commercial service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInHHIDExperiment': 'false',
    'isInAuthTokenExperiment': 'true',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmPageLoadId': '1',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fcommercial_services%2F',
    's_sq': '%5B%5BB%5D%5D',
    '_chartbeat2': '.1649184641023.1649215418941.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.94',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A23%3A39+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'ea5kMF9FVXRlcVIxZnJabThIeFRQVjYxck1GaHloekRRRGZvREtwbUw1OG43RmhBZUdUTWx2TU9IRUVtN3dDQ2xTQk9PZFByZzlLNXJzUUk0NHdvRVI1aXl3OHhhUUE3UzBkcm14cGRSdzBwR0tPTE9PQ0k0UlVYcHlzUW8zRlVXNFowMFhlVzVKbVRKMndRRGUyc0g5UjVTMmclM0QlM0Q',
    '_chartbeat4': 't=CDjGOGCD9saCBSaBGqBygKE4DL6yE7&E=15&x=300&c=1.89&y=1532&w=937',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'none',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInHHIDExperiment=false; isInAuthTokenExperiment=true; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmPageLoadId=1; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fcommercial_services%2F; s_sq=%5B%5BB%5D%5D; _chartbeat2=.1649184641023.1649215418941.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.94; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A23%3A39+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=ea5kMF9FVXRlcVIxZnJabThIeFRQVjYxck1GaHloekRRRGZvREtwbUw1OG43RmhBZUdUTWx2TU9IRUVtN3dDQ2xTQk9PZFByZzlLNXJzUUk0NHdvRVI1aXl3OHhhUUE3UzBkcm14cGRSdzBwR0tPTE9PQ0k0UlVYcHlzUW8zRlVXNFowMFhlVzVKbVRKMndRRGUyc0g5UjVTMmclM0QlM0Q; _chartbeat4=t=CDjGOGCD9saCBSaBGqBygKE4DL6yE7&E=15&x=300&c=1.89&y=1532&w=937',
}

params = {
    'page': '4',
}

response = requests.get('https://money.cnn.com/data/sectors/commercial_services/?page=4', headers=headers, params=params, cookies=cookies)
fo = open("./commercial service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    's_sq': '%5B%5BB%5D%5D',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A31%3A18+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    '_chartbeat2': '.1649184641023.1649215878380.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.102',
    '_chartbeat5': '',
    'cto_bundle': 'U85XiF9FVXRlcVIxZnJabThIeFRQVjYxck1KRTJhRmJFUVNmZTFUUHdkM01rUWhRaFBmbGYzRGZqdGJvJTJGSTJ6WlI5M2I0Z0RpZjNZY3Y2UUZIYk9NWVN4NVNEZ2FJbENFMWRQWGd6VXphZE10d2lTQ1hBaUdNZFZnNXk0TnBZNk03TlRIY2swZXRPRiUyRjJaSlNaSnA1UCUyQkFCTEElM0QlM0Q',
}

headers = {
    'authority': 'money.cnn.com',
    'cache-control': 'max-age=0',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/us_markets/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIvVbEAruQCW9boopjCGfP0EjMAEQAsATgAMpvADZF5dnJQJh1AwElb9x4spiArLlMA7ooIcDZ4fqYAwrIKyqrqVhCcAOaUBrggADQgwjAgZFR0jMwyxFkgEPSKMACMAL5AA; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; s_sq=%5B%5BB%5D%5D; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A31%3A18+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; _chartbeat2=.1649184641023.1649215878380.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.102; _chartbeat5=; cto_bundle=U85XiF9FVXRlcVIxZnJabThIeFRQVjYxck1KRTJhRmJFUVNmZTFUUHdkM01rUWhRaFBmbGYzRGZqdGJvJTJGSTJ6WlI5M2I0Z0RpZjNZY3Y2UUZIYk9NWVN4NVNEZ2FJbENFMWRQWGd6VXphZE10d2lTQ1hBaUdNZFZnNXk0TnBZNk03TlRIY2swZXRPRiUyRjJaSlNaSnA1UCUyQkFCTEElM0QlM0Q',
}

response = requests.get('https://money.cnn.com/data/sectors/tech/electronic/', headers=headers, cookies=cookies)
fo = open("./electronic technology.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F',
    '_chartbeat2': '.1649184641023.1649215912296.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.103',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A31%3A52+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': '0rcoZl9FVXRlcVIxZnJabThIeFRQVjYxck1MU1JVM1VadE5PVVBUaXUybllIVjRiVlpZVW05VTZCeGRFNm9ZRzJCbTZiOWo5Sm1GayUyRlg0MWQlMkZQV1RYeFFFWFZYTUN4RWZkSWZ4aVllUThya2RBZzd4bDJONzdVVTJvcDNWTFdFZnpjb2FpdUhib0J0OTZTam5vc0txYUVJbm9RJTNEJTNE',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Felectronic%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/tech/electronic/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F; _chartbeat2=.1649184641023.1649215912296.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.103; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A31%3A52+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=0rcoZl9FVXRlcVIxZnJabThIeFRQVjYxck1MU1JVM1VadE5PVVBUaXUybllIVjRiVlpZVW05VTZCeGRFNm9ZRzJCbTZiOWo5Sm1GayUyRlg0MWQlMkZQV1RYeFFFWFZYTUN4RWZkSWZ4aVllUThya2RBZzd4bDJONzdVVTJvcDNWTFdFZnpjb2FpdUhib0J0OTZTam5vc0txYUVJbm9RJTNEJTNE; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Felectronic%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '2',
}
response = requests.get('https://money.cnn.com/data/sectors/tech/electronic/?page=2', headers=headers, cookies=cookies)
fo = open("./electronic technology.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    '_chartbeat2': '.1649184641023.1649215982985.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.104',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A33%3A03+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': '6NKoPl9FVXRlcVIxZnJabThIeFRQVjYxck1MWlV3biUyRlVuQzRkWnFCRVdvS2NUaTRlSFZCNTBFZkFXdEs2MUpTaEowWXpwVWdUemNUREN1bnpiZzY4dzBpY0Z6WTdubVkwMllzRlNzbTVHOUclMkZrNmsxelIwa1drS3BvU1hxeGxqVnpkd201UnEwcCUyRldaZkljaFdXTUVqRFZvWkElM0QlM0Q',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Felectronic%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C3%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/tech/electronic/?page=2',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; _chartbeat2=.1649184641023.1649215982985.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.104; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A33%3A03+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=6NKoPl9FVXRlcVIxZnJabThIeFRQVjYxck1MWlV3biUyRlVuQzRkWnFCRVdvS2NUaTRlSFZCNTBFZkFXdEs2MUpTaEowWXpwVWdUemNUREN1bnpiZzY4dzBpY0Z6WTdubVkwMllzRlNzbTVHOUclMkZrNmsxelIwa1drS3BvU1hxeGxqVnpkd201UnEwcCUyRldaZkljaFdXTUVqRFZvWkElM0QlM0Q; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Felectronic%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C3%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '3',
}
response = requests.get('https://money.cnn.com/data/sectors/tech/electronic/?page=3', headers=headers, cookies=cookies)
fo = open("./electronic technology.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    '_chartbeat2': '.1649184641023.1649216058733.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.105',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A34%3A18+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'kxmHwV9FVXRlcVIxZnJabThIeFRQVjYxck1KTkhZNWkzQXNHMzZOR01FQXp2eDFoa0tKblVReVYwV05DUDU4Rm5uMVBUdFlycmglMkJoTllrb21IRk9WSEp4N0ZJWVF4Sm9JMDlRSHYyUnByWHJxcWkzZFd6MXhScmVQaEYlMkI4dVBaTjhGaVR6dDFHUVVuVUozNkF6cjlpcFFkJTJGamclM0QlM0Q',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Felectronic%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C4%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/tech/electronic/?page=3',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; _chartbeat2=.1649184641023.1649216058733.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.105; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A34%3A18+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=kxmHwV9FVXRlcVIxZnJabThIeFRQVjYxck1KTkhZNWkzQXNHMzZOR01FQXp2eDFoa0tKblVReVYwV05DUDU4Rm5uMVBUdFlycmglMkJoTllrb21IRk9WSEp4N0ZJWVF4Sm9JMDlRSHYyUnByWHJxcWkzZFd6MXhScmVQaEYlMkI4dVBaTjhGaVR6dDFHUVVuVUozNkF6cjlpcFFkJTJGamclM0QlM0Q; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Felectronic%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C4%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '4',
}
response = requests.get('https://money.cnn.com/data/sectors/tech/electronic/?page=4', headers=headers, cookies=cookies)
fo = open("./electronic technology.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    '_chartbeat2': '.1649184641023.1649216164139.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.108',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A36%3A04+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'mgw9VF9FVXRlcVIxZnJabThIeFRQVjYxck1CJTJCMnlnRlhFQUNIR0hLWkNBWHRBalZWNjY5YlJkYlBTUkhrdFVCU0JNc2ZtaVp2eEVkWk1PSFcwc3lhTmxXNWZMdXAlMkZ1OENTb2Y1dUQ0UzFuWXY3bXFsRnFJNCUyRmNweEZLMmxJViUyQm4ybndBM3hYbmZzelRRYVFzYVpjYnB6SU5uQSUzRCUzRA',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Felectronic%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C5%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/tech/electronic/?page=4',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Felectronic%2F; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; _chartbeat2=.1649184641023.1649216164139.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.108; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A36%3A04+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=mgw9VF9FVXRlcVIxZnJabThIeFRQVjYxck1CJTJCMnlnRlhFQUNIR0hLWkNBWHRBalZWNjY5YlJkYlBTUkhrdFVCU0JNc2ZtaVp2eEVkWk1PSFcwc3lhTmxXNWZMdXAlMkZ1OENTb2Y1dUQ0UzFuWXY3bXFsRnFJNCUyRmNweEZLMmxJViUyQm4ybndBM3hYbmZzelRRYVFzYVpjYnB6SU5uQSUzRCUzRA; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Felectronic%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C5%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '5',
}
response = requests.get('https://money.cnn.com/data/sectors/tech/electronic/?page=5', headers=headers, cookies=cookies)
fo = open("./electronic technology.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    's_sq': '%5B%5BB%5D%5D',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fenergy_minerals%2F',
    '_chartbeat5': '',
    '_chartbeat2': '.1649184641023.1649216277030.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.112',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A37%3A57+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': '5cYnS19FVXRlcVIxZnJabThIeFRQVjYxck1GczFhZFVkdVB6a29Hck56NDdDMFgxQWtlOGV1JTJCYnFjTW1pb05Pc2IlMkZqJTJGNWs1JTJGbXFWWm1IZ01LS21tZGl2VXkxdVZLNUVIJTJCdHBqYiUyQms1ZFBpZDFtJTJGSiUyRnpqc1RUTFJUJTJGRWNRaVhibFY0emw2cnRrcjR2b1hPJTJCenl6eGNQYmJXZyUzRCUzRA',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/us_markets/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; s_sq=%5B%5BB%5D%5D; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fenergy_minerals%2F; _chartbeat5=; _chartbeat2=.1649184641023.1649216277030.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.112; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A37%3A57+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=5cYnS19FVXRlcVIxZnJabThIeFRQVjYxck1GczFhZFVkdVB6a29Hck56NDdDMFgxQWtlOGV1JTJCYnFjTW1pb05Pc2IlMkZqJTJGNWs1JTJGbXFWWm1IZ01LS21tZGl2VXkxdVZLNUVIJTJCdHBqYiUyQms1ZFBpZDFtJTJGSiUyRnpqc1RUTFJUJTJGRWNRaVhibFY0emw2cnRrcjR2b1hPJTJCenl6eGNQYmJXZyUzRCUzRA',
}

response = requests.get('https://money.cnn.com/data/sectors/energy_minerals/', headers=headers, cookies=cookies)   ###yiye
fo = open("./energy minerals.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()



cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649216609.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fenergy_minerals%2F',
    '_chartbeat2': '.1649184641023.1649216610309.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.119',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A43%3A30+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'Fmyez19FVXRlcVIxZnJabThIeFRQVjYxck1JJTJGd3k2dktmVGFQeERYVVFYMWdSYWlrWEZCa1klMkZNMCUyQkcwTGFndWVEQVVZU0NzSWM2TiUyQjA4SGEyMmdVZW01Q0p0MTQxS0w3UFE5amJQRlJGRGt4JTJCSE5JV08lMkZKalZvbHlZYUJJU3pMN0FGOVolMkZYa2Uwa3Z3dnJPWFlDZ29PVW5NUSUzRCUzRA',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C1%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/finance/?page=2',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649216609.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fenergy_minerals%2F; _chartbeat2=.1649184641023.1649216610309.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.119; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A43%3A30+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=Fmyez19FVXRlcVIxZnJabThIeFRQVjYxck1JJTJGd3k2dktmVGFQeERYVVFYMWdSYWlrWEZCa1klMkZNMCUyQkcwTGFndWVEQVVZU0NzSWM2TiUyQjA4SGEyMmdVZW01Q0p0MTQxS0w3UFE5amJQRlJGRGt4JTJCSE5JV08lMkZKalZvbHlZYUJJU3pMN0FGOVolMkZYa2Uwa3Z3dnJPWFlDZ29PVW5NUSUzRCUzRA; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C1%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '1',
}

response = requests.get('https://money.cnn.com/data/sectors/finance/', headers=headers, params=params, cookies=cookies)
fo = open("./finance.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ffinance%2F',
    '_chartbeat2': '.1649184641023.1649216375450.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.115',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A39%3A35+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'UJSTNF9FVXRlcVIxZnJabThIeFRQVjYxck1LSUw2UzNmTjJqMlZoTER1MFV2WlN1T05HJTJGOGRGUXFzbFJEZGZhNiUyQkNqUjNrV1NldjVPJTJCUGVSeHFpOWklMkJpQm95aiUyRlYlMkZMQkhxc3c1Z29QeUg2MGdhMXdlbGl0NHNNZmlRQXRkYU1FcmczTUt6SDYxVmlabmJQYjhReCUyQiUyRmZPWUFRJTNEJTNE',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/finance/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649215142.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ffinance%2F; _chartbeat2=.1649184641023.1649216375450.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.115; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A39%3A35+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=UJSTNF9FVXRlcVIxZnJabThIeFRQVjYxck1LSUw2UzNmTjJqMlZoTER1MFV2WlN1T05HJTJGOGRGUXFzbFJEZGZhNiUyQkNqUjNrV1NldjVPJTJCUGVSeHFpOWklMkJpQm95aiUyRlYlMkZMQkhxc3c1Z29QeUg2MGdhMXdlbGl0NHNNZmlRQXRkYU1FcmczTUt6SDYxVmlabmJQYjhReCUyQiUyRmZPWUFRJTNEJTNE; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '2',
}
response = requests.get('https://money.cnn.com/data/sectors/finance/?page=2', headers=headers, cookies=cookies)
fo = open("./finance.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D11%7C176917733%3D11',
    'mnjs_session_depth': '3%7C1649214859099',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649216609.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ffinance%2F',
    'cto_bundle': 'EpqJHl9FVXRlcVIxZnJabThIeFRQVjYxck1HQkNZMDRIcllvZUslMkZqYlRMR1RHRk5JRUglMkJmZktBYVFYRSUyQjczWXUyZDVlM3lhTVgzRlpBcG5mYmwlMkJVRHZ1SGpuWXFhYkFqSzNuM28zMElBcTVMOGZjcXRrWTdQUjlWTE9pMjhoOVhEZHBiZWRDVGd5NjRiQnE5YjhHYWxpNVJrdyUzRCUzRA',
    '_chartbeat2': '.1649184641023.1649216867249.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.121',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A47%3A47+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C3%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/finance/?page=2',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D11%7C176917733%3D11; mnjs_session_depth=3%7C1649214859099; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649216609.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ffinance%2F; cto_bundle=EpqJHl9FVXRlcVIxZnJabThIeFRQVjYxck1HQkNZMDRIcllvZUslMkZqYlRMR1RHRk5JRUglMkJmZktBYVFYRSUyQjczWXUyZDVlM3lhTVgzRlpBcG5mYmwlMkJVRHZ1SGpuWXFhYkFqSzNuM28zMElBcTVMOGZjcXRrWTdQUjlWTE9pMjhoOVhEZHBiZWRDVGd5NjRiQnE5YjhHYWxpNVJrdyUzRCUzRA; _chartbeat2=.1649184641023.1649216867249.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.121; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A47%3A47+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C3%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '3',
}

response = requests.get('https://money.cnn.com/data/sectors/finance/?page=3', headers=headers, params=params, cookies=cookies)

fo = open("./finance.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'mnjs_session_depth': '3%7C1649214859099',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649216609.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ffinance%2F',
    '_chartbeat2': '.1649184641023.1649216900480.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.122',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A48%3A20+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'zie60F9FVXRlcVIxZnJabThIeFRQVjYxck1GcVpJdGtBaWlNVGN1T0pYTmR5NXlRYUkyOFozRmJ2aTBiQ1BLWUpoaXpkQ0lsZ2dPNmxYUEl6QUxyTXJ5Y0c4TUduRkRUd3U2Rzh3dGZ1dlBxdmVFVHRFcWVoOHglMkJWWmZkMnU2SVYlMkJ2UUF6VSUyQk1CNWNNJTJGMjNRM2lNREolMkZZd2JBJTNEJTNE',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C4%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/finance/?page=3',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; mnjs_session_depth=3%7C1649214859099; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649216609.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ffinance%2F; _chartbeat2=.1649184641023.1649216900480.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.122; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A48%3A20+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=zie60F9FVXRlcVIxZnJabThIeFRQVjYxck1GcVpJdGtBaWlNVGN1T0pYTmR5NXlRYUkyOFozRmJ2aTBiQ1BLWUpoaXpkQ0lsZ2dPNmxYUEl6QUxyTXJ5Y0c4TUduRkRUd3U2Rzh3dGZ1dlBxdmVFVHRFcWVoOHglMkJWWmZkMnU2SVYlMkJ2UUF6VSUyQk1CNWNNJTJGMjNRM2lNREolMkZZd2JBJTNEJTNE; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C4%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '4',
}

response = requests.get('https://money.cnn.com/data/sectors/finance/?page=4', headers=headers, params=params, cookies=cookies)
fo = open("./finance.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'mnjs_session_depth': '3%7C1649214859099',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649216609.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ffinance%2F',
    '_chartbeat2': '.1649184641023.1649217003117.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.125',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A50%3A03+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': '-mwnfF9FVXRlcVIxZnJabThIeFRQVjYxck1PRHFOTThjREFQZEpSZHh6JTJGM29JTExvSEZEd0RxdTJxcUlJNiUyQktuMjJ2S1Bmd2daWm9iSzJIRCUyRlRyMHdXVnZ3ZnRnRGRaQ21KNDBLNnV5TklLQWxRaUFaS3JuNEwzNHZ0Rk5xbjUlMkY2eEM0cTNFU2hpRzh3ZlZkMllUOEslMkZ3UlRnJTNEJTNE',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C5%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/finance/?page=4',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; mnjs_session_depth=3%7C1649214859099; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649216609.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ffinance%2F; _chartbeat2=.1649184641023.1649217003117.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.125; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A50%3A03+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=-mwnfF9FVXRlcVIxZnJabThIeFRQVjYxck1PRHFOTThjREFQZEpSZHh6JTJGM29JTExvSEZEd0RxdTJxcUlJNiUyQktuMjJ2S1Bmd2daWm9iSzJIRCUyRlRyMHdXVnZ3ZnRnRGRaQ21KNDBLNnV5TklLQWxRaUFaS3JuNEwzNHZ0Rk5xbjUlMkY2eEM0cTNFU2hpRzh3ZlZkMllUOEslMkZ3UlRnJTNEJTNE; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ffinance%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C5%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '5',
}

response = requests.get('https://money.cnn.com/data/sectors/finance/?page=5', headers=headers, params=params, cookies=cookies)
fo = open("./finance.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmPageLoadId': '1',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D1%7C176917733%3D1',
    'mnjs_session_depth': '1%7C1649217065983',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217068.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    's_sq': '%5B%5BB%5D%5D',
    'cto_bundle': 'jx528l9FVXRlcVIxZnJabThIeFRQVjYxck1PbWZ0NEFEeTF1Mkw4aUhaeUY1bzBxNjlsQnNzU1B4bjlsMzM3c2NPQk1NY0NOZnNiQk8wMXBBSm90VjlCZTc1cW5vMHVXQUFieVU1RUpTTGpUSk5JbElyQnQ4Q3JscnhHank4Z21tVndEMXlOdW5HV1lyNXl2cUpTSm9rbE9GbEElM0QlM0Q',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fhealth_services%2F',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A51%3A41+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    '_chartbeat2': '.1649184641023.1649217101372.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.134',
    '_chartbeat5': '',
    '_chartbeat4': 't=BoNYAqB-GkX4CJTjE2CLMRFiQR7fW&E=0&x=54&c=13.65&y=1392&w=937',
}

headers = {
    'authority': 'money.cnn.com',
    'cache-control': 'max-age=0',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/us_markets/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmPageLoadId=1; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D1%7C176917733%3D1; mnjs_session_depth=1%7C1649217065983; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217068.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; s_sq=%5B%5BB%5D%5D; cto_bundle=jx528l9FVXRlcVIxZnJabThIeFRQVjYxck1PbWZ0NEFEeTF1Mkw4aUhaeUY1bzBxNjlsQnNzU1B4bjlsMzM3c2NPQk1NY0NOZnNiQk8wMXBBSm90VjlCZTc1cW5vMHVXQUFieVU1RUpTTGpUSk5JbElyQnQ4Q3JscnhHank4Z21tVndEMXlOdW5HV1lyNXl2cUpTSm9rbE9GbEElM0QlM0Q; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fhealth_services%2F; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A51%3A41+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; _chartbeat2=.1649184641023.1649217101372.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.134; _chartbeat5=; _chartbeat4=t=BoNYAqB-GkX4CJTjE2CLMRFiQR7fW&E=0&x=54&c=13.65&y=1392&w=937',
}

response = requests.get('https://money.cnn.com/data/sectors/health_services/', headers=headers, cookies=cookies)
fo = open("./health service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInHHIDExperiment': 'false',
    'isInAuthTokenExperiment': 'true',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmPageLoadId': '1',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D1%7C176917733%3D1',
    'mnjs_session_depth': '1%7C1649217065983',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217068.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cto_bundle': 'jx528l9FVXRlcVIxZnJabThIeFRQVjYxck1PbWZ0NEFEeTF1Mkw4aUhaeUY1bzBxNjlsQnNzU1B4bjlsMzM3c2NPQk1NY0NOZnNiQk8wMXBBSm90VjlCZTc1cW5vMHVXQUFieVU1RUpTTGpUSk5JbElyQnQ4Q3JscnhHank4Z21tVndEMXlOdW5HV1lyNXl2cUpTSm9rbE9GbEElM0QlM0Q',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fhealth_services%2F',
    '_chartbeat5': '',
    '_chartbeat2': '.1649184641023.1649217110046.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.135',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A51%3A50+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Fhealth_services%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/health_services/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInHHIDExperiment=false; isInAuthTokenExperiment=true; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmPageLoadId=1; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D1%7C176917733%3D1; mnjs_session_depth=1%7C1649217065983; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217068.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cto_bundle=jx528l9FVXRlcVIxZnJabThIeFRQVjYxck1PbWZ0NEFEeTF1Mkw4aUhaeUY1bzBxNjlsQnNzU1B4bjlsMzM3c2NPQk1NY0NOZnNiQk8wMXBBSm90VjlCZTc1cW5vMHVXQUFieVU1RUpTTGpUSk5JbElyQnQ4Q3JscnhHank4Z21tVndEMXlOdW5HV1lyNXl2cUpTSm9rbE9GbEElM0QlM0Q; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fhealth_services%2F; _chartbeat5=; _chartbeat2=.1649184641023.1649217110046.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.135; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A51%3A50+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Fhealth_services%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '2',
}

response = requests.get('https://money.cnn.com/data/sectors/health_services/?page=2', headers=headers, params=params, cookies=cookies)
fo = open("./health service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInHHIDExperiment': 'false',
    'isInAuthTokenExperiment': 'true',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D1%7C176917733%3D1',
    'mnjs_session_depth': '1%7C1649217065983',
    'cto_bundle': 'jx528l9FVXRlcVIxZnJabThIeFRQVjYxck1PbWZ0NEFEeTF1Mkw4aUhaeUY1bzBxNjlsQnNzU1B4bjlsMzM3c2NPQk1NY0NOZnNiQk8wMXBBSm90VjlCZTc1cW5vMHVXQUFieVU1RUpTTGpUSk5JbElyQnQ4Q3JscnhHank4Z21tVndEMXlOdW5HV1lyNXl2cUpTSm9rbE9GbEElM0QlM0Q',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fhealth_services%2F',
    '_chartbeat2': '.1649184641023.1649217157810.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.136',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A52%3A37+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fus_markets%25252F%2526pidt%253D1%2526oid%253Dhttps%25253A%25252F%25252Fmoney.cnn.com%25252Fdata%25252Fsectors%25252Fretail_trade%25252F%2526ot%253DA',
    '_chartbeat5': '190|716|%2Fdata%2Fus_markets%2F|https%3A%2F%2Fmoney.cnn.com%2Fdata%2Fsectors%2Fretail_trade%2F|DUDZ6DB7_nSrrVgt_B80Da_CAgtI1||c|C5UwPrCJkcZTD627reDw2Vr1DXkyP9|cnn.com|',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217200.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/us_markets/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInHHIDExperiment=false; isInAuthTokenExperiment=true; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D1%7C176917733%3D1; mnjs_session_depth=1%7C1649217065983; cto_bundle=jx528l9FVXRlcVIxZnJabThIeFRQVjYxck1PbWZ0NEFEeTF1Mkw4aUhaeUY1bzBxNjlsQnNzU1B4bjlsMzM3c2NPQk1NY0NOZnNiQk8wMXBBSm90VjlCZTc1cW5vMHVXQUFieVU1RUpTTGpUSk5JbElyQnQ4Q3JscnhHank4Z21tVndEMXlOdW5HV1lyNXl2cUpTSm9rbE9GbEElM0QlM0Q; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fhealth_services%2F; _chartbeat2=.1649184641023.1649217157810.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.136; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A52%3A37+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fus_markets%25252F%2526pidt%253D1%2526oid%253Dhttps%25253A%25252F%25252Fmoney.cnn.com%25252Fdata%25252Fsectors%25252Fretail_trade%25252F%2526ot%253DA; _chartbeat5=190|716|%2Fdata%2Fus_markets%2F|https%3A%2F%2Fmoney.cnn.com%2Fdata%2Fsectors%2Fretail_trade%2F|DUDZ6DB7_nSrrVgt_B80Da_CAgtI1||c|C5UwPrCJkcZTD627reDw2Vr1DXkyP9|cnn.com|; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217200.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
}

response = requests.get('https://money.cnn.com/data/sectors/retail_trade/', headers=headers, cookies=cookies)
fo = open("./retail trade.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmPageLoadId': '1',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D2%7C176917733%3D2',
    'mnjs_session_depth': '2%7C1649217065983',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fretail_trade%2F',
    '_chartbeat5': '',
    's_sq': '%5B%5BB%5D%5D',
    '_chartbeat2': '.1649184641023.1649217363178.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.140',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A56%3A03+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'dDSnWV9FVXRlcVIxZnJabThIeFRQVjYxck1MaGgyYXNUUVp1UiUyRkhoUGNycTNiODJSZU9Ud3R6aEFCNWxKS0V1MkFQJTJCZCUyQkVCRXFkTUxXeG1GaE40OTdpOGw1Z1ZkRTdnUTFJckQxaFZVck1naGlYOWdDR3NmN3VObFp2TGlFNFYlMkJMN0ZWQyUyRkRGNmx3UXZMSkVzQWJuaDhjYWZRJTNEJTNE',
}

headers = {
    'authority': 'money.cnn.com',
    'cache-control': 'max-age=0',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/retail_trade/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmPageLoadId=1; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D2%7C176917733%3D2; mnjs_session_depth=2%7C1649217065983; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Fretail_trade%2F; _chartbeat5=; s_sq=%5B%5BB%5D%5D; _chartbeat2=.1649184641023.1649217363178.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.140; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A56%3A03+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=dDSnWV9FVXRlcVIxZnJabThIeFRQVjYxck1MaGgyYXNUUVp1UiUyRkhoUGNycTNiODJSZU9Ud3R6aEFCNWxKS0V1MkFQJTJCZCUyQkVCRXFkTUxXeG1GaE40OTdpOGw1Z1ZkRTdnUTFJckQxaFZVck1naGlYOWdDR3NmN3VObFp2TGlFNFYlMkJMN0ZWQyUyRkRGNmx3UXZMSkVzQWJuaDhjYWZRJTNEJTNE',
}

params = {
    'page': '2',
}

response = requests.get('https://money.cnn.com/data/sectors/retail_trade/?page=2', headers=headers, params=params, cookies=cookies)
fo = open("./retail trade.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmPageLoadId': '1',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D2%7C176917733%3D2',
    'mnjs_session_depth': '2%7C1649217065983',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    's_sq': '%5B%5BB%5D%5D',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fservices%2F',
    '_chartbeat2': '.1649184641023.1649217421143.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.144',
    '_chartbeat5': '',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A57%3A01+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': 'p1cQql9FVXRlcVIxZnJabThIeFRQVjYxck1FWHZSNEZqOTVIYWdiY3ZRSkdzOTFPc1A5WEcyaE9ZaDk2cTVVZUZtU2RCUWFXMFdtWVNKZkVITmF6a1hIY1kwZWRGQmU3VTQ1cGlUdHRRQmhWSzRiNTllOEhoJTJCVEw0TkV4OFAlMkZ3aXh4MnFrN0t0WGpTTG9GN1VBWm0lMkIwN0VVSFElM0QlM0Q',
}

headers = {
    'authority': 'money.cnn.com',
    'cache-control': 'max-age=0',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/us_markets/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmPageLoadId=1; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D2%7C176917733%3D2; mnjs_session_depth=2%7C1649217065983; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; s_sq=%5B%5BB%5D%5D; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fservices%2F; _chartbeat2=.1649184641023.1649217421143.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.144; _chartbeat5=; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A57%3A01+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=p1cQql9FVXRlcVIxZnJabThIeFRQVjYxck1FWHZSNEZqOTVIYWdiY3ZRSkdzOTFPc1A5WEcyaE9ZaDk2cTVVZUZtU2RCUWFXMFdtWVNKZkVITmF6a1hIY1kwZWRGQmU3VTQ1cGlUdHRRQmhWSzRiNTllOEhoJTJCVEw0TkV4OFAlMkZ3aXh4MnFrN0t0WGpTTG9GN1VBWm0lMkIwN0VVSFElM0QlM0Q',
}

response = requests.get('https://money.cnn.com/data/sectors/tech/services/', headers=headers, cookies=cookies)
fo = open("./technology service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D2%7C176917733%3D2',
    'mnjs_session_depth': '2%7C1649217065983',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fservices%2F',
    '_chartbeat2': '.1649184641023.1649217427988.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.145',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A57%3A08+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': '-rKi1F9FVXRlcVIxZnJabThIeFRQVjYxck1FU09vbXdYd3JPZjNiQWlqUERIWG1UJTJGbWU3TjJQckpxd2VvZExNYXhaNlQybXFiJTJCNWN3eE9hYngwQ1lTclZEZ0JCZnVSWWVFZGJURiUyRkFYdVJQMGZPZXpkQXFvTGs0MXNyMUFMbkRqSiUyRllxMU96dTByeWtuTVpYWGZuZDYyWkZ3dyUzRCUzRA',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Fservices%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/tech/services/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D2%7C176917733%3D2; mnjs_session_depth=2%7C1649217065983; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fservices%2F; _chartbeat2=.1649184641023.1649217427988.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.145; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A57%3A08+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=-rKi1F9FVXRlcVIxZnJabThIeFRQVjYxck1FU09vbXdYd3JPZjNiQWlqUERIWG1UJTJGbWU3TjJQckpxd2VvZExNYXhaNlQybXFiJTJCNWN3eE9hYngwQ1lTclZEZ0JCZnVSWWVFZGJURiUyRkFYdVJQMGZPZXpkQXFvTGs0MXNyMUFMbkRqSiUyRllxMU96dTByeWtuTVpYWGZuZDYyWkZ3dyUzRCUzRA; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Fservices%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '2',
}

response = requests.get('https://money.cnn.com/data/sectors/tech/services/?page=2', headers=headers, params=params, cookies=cookies)
fo = open("./technology service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D2%7C176917733%3D2',
    'mnjs_session_depth': '2%7C1649217065983',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fservices%2F',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A58%3A14+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    '_chartbeat2': '.1649184641023.1649217494683.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.146',
    'cto_bundle': 'JhRsj19FVXRlcVIxZnJabThIeFRQVjYxck1FeG9kdHZGYWFzanc4YWkwb05MdUJOWDF2c1QlMkJpSzJQTjZMTlhTd1A0bWswUUt6TWFiSyUyRlRPTVV6MkNGZnAwWFZNSWZtdExxdEI2ZFcwTm85MSUyRmh2MWpxQlQzTFVjJTJGTUVuUE56STJib2VMdGhTUnBqRUhOZ3BXbWpnR3prMVdsZyUzRCUzRA',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Fservices%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C3%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/tech/services/?page=2',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D2%7C176917733%3D2; mnjs_session_depth=2%7C1649217065983; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fservices%2F; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A58%3A14+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; _chartbeat2=.1649184641023.1649217494683.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.146; cto_bundle=JhRsj19FVXRlcVIxZnJabThIeFRQVjYxck1FeG9kdHZGYWFzanc4YWkwb05MdUJOWDF2c1QlMkJpSzJQTjZMTlhTd1A0bWswUUt6TWFiSyUyRlRPTVV6MkNGZnAwWFZNSWZtdExxdEI2ZFcwTm85MSUyRmh2MWpxQlQzTFVjJTJGTUVuUE56STJib2VMdGhTUnBqRUhOZ3BXbWpnR3prMVdsZyUzRCUzRA; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Fservices%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C3%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '3',
}

response = requests.get('https://money.cnn.com/data/sectors/tech/services/?page=3', headers=headers, params=params, cookies=cookies)
fo = open("./technology service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendHHID': 'false',
    'sendAuthToken': 'true',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'WSOD%5FxrefSymbol': 'SHEN',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D2%7C176917733%3D2',
    'mnjs_session_depth': '2%7C1649217065983',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fservices%2F',
    '_chartbeat2': '.1649184641023.1649217543721.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.147',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A59%3A03+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    'cto_bundle': '0ArAXl9FVXRlcVIxZnJabThIeFRQVjYxck1OYzVIVk5rRFNIdE5hcTA3c2lHSVBzc05MMiUyQmtnY1VXNCUyRkJid21uczY0eiUyRmppOHJITWg2Q0FudFBtdSUyQjhaUVlNVnhYam54M0U5S1NVWUkzWE01JTJGJTJCU0JYSnBsT21LQmF5WWZWYSUyRjRmYUp0TWJpVnBCaW94SDc1VFFWSEZLYlg2ZyUzRCUzRA',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Fservices%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C4%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/tech/services/?page=3',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendHHID=false; sendAuthToken=true; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; WSOD%5FxrefSymbol=SHEN; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D2%7C176917733%3D2; mnjs_session_depth=2%7C1649217065983; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftech%2Fservices%2F; _chartbeat2=.1649184641023.1649217543721.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.147; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+22%3A59%3A03+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; cto_bundle=0ArAXl9FVXRlcVIxZnJabThIeFRQVjYxck1OYzVIVk5rRFNIdE5hcTA3c2lHSVBzc05MMiUyQmtnY1VXNCUyRkJid21uczY0eiUyRmppOHJITWg2Q0FudFBtdSUyQjhaUVlNVnhYam54M0U5S1NVWUkzWE01JTJGJTJCU0JYSnBsT21LQmF5WWZWYSUyRjRmYUp0TWJpVnBCaW94SDc1VFFWSEZLYlg2ZyUzRCUzRA; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Ftech%25252Fservices%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C4%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '4',
}

response = requests.get('https://money.cnn.com/data/sectors/tech/services/?page=4', headers=headers, params=params, cookies=cookies)
fo = open("./technology service.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInAuthTokenExperiment': 'true',
    'isInHHIDExperiment': 'false',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmPageLoadId': '1',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D2%7C176917733%3D2',
    'mnjs_session_depth': '2%7C1649217065983',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    's_sq': '%5B%5BB%5D%5D',
    'cto_bundle': 'umwQu19FVXRlcVIxZnJabThIeFRQVjYxck1KM3lPRDBqYW5QJTJCd0JPYndwZDEyM09PTDA3UDNrT09qOVZyRGIwTElWRFc3TU5jZnJTOXduWU5lWjhzdyUyRkRyZU9tbFh6cGtEN29WU3hQUmxDN2pmTVA2cDYlMkIzUzZFJTJCaUczRURtOWowbDBDNVFRamdZSiUyQkhnR3hXdUhubW9QUkp3JTNEJTNE',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftransportation%2F',
    '_chartbeat2': '.1649184641023.1649217642398.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.149',
    '_chartbeat5': '',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+23%3A00%3A42+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
}

headers = {
    'authority': 'money.cnn.com',
    'cache-control': 'max-age=0',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/us_markets/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInAuthTokenExperiment=true; isInHHIDExperiment=false; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmPageLoadId=1; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D2%7C176917733%3D2; mnjs_session_depth=2%7C1649217065983; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217341.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; s_sq=%5B%5BB%5D%5D; cto_bundle=umwQu19FVXRlcVIxZnJabThIeFRQVjYxck1KM3lPRDBqYW5QJTJCd0JPYndwZDEyM09PTDA3UDNrT09qOVZyRGIwTElWRFc3TU5jZnJTOXduWU5lWjhzdyUyRkRyZU9tbFh6cGtEN29WU3hQUmxDN2pmTVA2cDYlMkIzUzZFJTJCaUczRURtOWowbDBDNVFRamdZSiUyQkhnR3hXdUhubW9QUkp3JTNEJTNE; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftransportation%2F; _chartbeat2=.1649184641023.1649217642398.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.149; _chartbeat5=; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+23%3A00%3A42+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
}

response = requests.get('https://money.cnn.com/data/sectors/transportation/', headers=headers, cookies=cookies)
fo = open("./transportation.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInHHIDExperiment': 'false',
    'isInAuthTokenExperiment': 'true',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'bounceClientVisit340v': 'N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA',
    'session_depth': 'money.cnn.com%3D2%7C176917733%3D2',
    'mnjs_session_depth': '2%7C1649217065983',
    'cto_bundle': 'umwQu19FVXRlcVIxZnJabThIeFRQVjYxck1KM3lPRDBqYW5QJTJCd0JPYndwZDEyM09PTDA3UDNrT09qOVZyRGIwTElWRFc3TU5jZnJTOXduWU5lWjhzdyUyRkRyZU9tbFh6cGtEN29WU3hQUmxDN2pmTVA2cDYlMkIzUzZFJTJCaUczRURtOWowbDBDNVFRamdZSiUyQkhnR3hXdUhubW9QUkp3JTNEJTNE',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftransportation%2F',
    '_chartbeat2': '.1649184641023.1649217648009.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.150',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+23%3A00%3A48+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fus_markets%25252F%2526pidt%253D1%2526oid%253Dhttps%25253A%25252F%25252Fmoney.cnn.com%25252Fdata%25252Fsectors%25252Futilities%25252F%2526ot%253DA',
    '_chartbeat5': '190|791|%2Fdata%2Fus_markets%2F|https%3A%2F%2Fmoney.cnn.com%2Fdata%2Fsectors%2Futilities%2F|DzcBX289ZGAl0TUXm6q7yDyAq51||c|CrFVFmCop5LpBjlE8wBoXJiHdrGz3|cnn.com|',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217723.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/us_markets/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInHHIDExperiment=false; isInAuthTokenExperiment=true; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; bounceClientVisit340v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgLYD2AdgKYCeAdAMbnkOnFEAmAhgp0SpfQSkATugIIBcIpTACEwigEt6RTPgicA5pUwARXCAA0IYTBBkqdRs3qsQAXyA; session_depth=money.cnn.com%3D2%7C176917733%3D2; mnjs_session_depth=2%7C1649217065983; cto_bundle=umwQu19FVXRlcVIxZnJabThIeFRQVjYxck1KM3lPRDBqYW5QJTJCd0JPYndwZDEyM09PTDA3UDNrT09qOVZyRGIwTElWRFc3TU5jZnJTOXduWU5lWjhzdyUyRkRyZU9tbFh6cGtEN29WU3hQUmxDN2pmTVA2cDYlMkIzUzZFJTJCaUczRURtOWowbDBDNVFRamdZSiUyQkhnR3hXdUhubW9QUkp3JTNEJTNE; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Ftransportation%2F; _chartbeat2=.1649184641023.1649217648009.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.150; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+23%3A00%3A48+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fus_markets%25252F%2526pidt%253D1%2526oid%253Dhttps%25253A%25252F%25252Fmoney.cnn.com%25252Fdata%25252Fsectors%25252Futilities%25252F%2526ot%253DA; _chartbeat5=190|791|%2Fdata%2Fus_markets%2F|https%3A%2F%2Fmoney.cnn.com%2Fdata%2Fsectors%2Futilities%2F|DzcBX289ZGAl0TUXm6q7yDyAq51||c|CrFVFmCop5LpBjlE8wBoXJiHdrGz3|cnn.com|; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217723.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
}

response = requests.get('https://money.cnn.com/data/sectors/utilities/', headers=headers, cookies=cookies)
fo = open("./utilities.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()

cookies = {
    'FastAB': '0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537',
    'optimizelyEndUserId': 'oeu1649184640328r0.43775867948414793',
    's_fid': '5BCCF7323793C18F-1BD742756E695FD7',
    's_vi': '[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]',
    'ugs': '1',
    'ug': '624c8f800c13ae0a3f9083001668f38c',
    '_cb_ls': '1',
    '_cb': 'iBns8jK6arBV-EqQ',
    'OB-USER-TOKEN': '2774002a-017f-448d-ae97-74d4b9d8f531',
    '_pbjs_userid_consent_data': '3524755945110770',
    '__qca': 'P0-1079014940-1649184641582',
    'OptanonControl': 'ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5',
    '__gads': 'ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA',
    '_fbp': 'fb.1.1649184642929.1834398661',
    'umto': '1',
    '_hjSessionUser_1466492': 'eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=',
    'hkgc': '09e4e1b4-2604-11ec-89a9-151a31250201',
    'zwmc': '2127012215019385808',
    'goiz': 'ee0eb4b92f9848deb2f252c26b5c9957',
    'ifyr': 'KSWOJMV8-2-A4FJ',
    'bea4': 'c082_7017581334479357558',
    'WMUKID_STABLE': 'bb073be7-ea8f-4daa-af4e-cfa95e4a17b3',
    'CDPID': '{"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}',
    'sendAuthToken': 'true',
    'sendHHID': 'false',
    'isInHHIDExperiment': 'false',
    'isInAuthTokenExperiment': 'true',
    'sendWMSegs': 'false',
    'idrTimestamp': '%222022-04-05T18%3A51%3A33.043Z%22',
    '_admrla': '2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59',
    '_pubcid': '87e0a039-f67a-4951-a2ab-8c835654b82b',
    'AMCV_7FF852E2556756057F000101%40AdobeOrg': '-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0',
    'btIdentify': '5c2177a0-13c1-4ef9-a966-505a7c335368',
    'last5stocks': 'SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC',
    '_ga': 'GA1.2.30076962.1649189309',
    '_gid': 'GA1.2.1179730247.1649189309',
    'SelectedEdition': 'www',
    'countryCode': 'US',
    'stateCode': 'IL',
    'geoData': 'urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220',
    'usprivacy': '1YNN',
    's_cc': 'true',
    '_sp_ses.f5fb': '*',
    '_bti': '%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D',
    'psmSessionId': '3373055f-4b72-4860-9599-12fcbecb0dc8',
    'psmSessionStart': '2022-04-06T02%3A12%3A08.365Z',
    'psmPageLoadId': '1',
    '_awl': '2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0',
    'psmLastActiveTimestamp': '2022-04-06T02%3A12%3A10.509Z',
    '_cb_svref': 'null',
    '__gpi': 'UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g',
    'session_depth': 'money.cnn.com%3D2%7C176917733%3D2',
    'mnjs_session_depth': '2%7C1649217065983',
    'cto_bundle': 'umwQu19FVXRlcVIxZnJabThIeFRQVjYxck1KM3lPRDBqYW5QJTJCd0JPYndwZDEyM09PTDA3UDNrT09qOVZyRGIwTElWRFc3TU5jZnJTOXduWU5lWjhzdyUyRkRyZU9tbFh6cGtEN29WU3hQUmxDN2pmTVA2cDYlMkIzUzZFJTJCaUczRURtOWowbDBDNVFRamdZSiUyQkhnR3hXdUhubW9QUkp3JTNEJTNE',
    '_sp_id.f5fb': '1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217723.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655',
    'cnprevpage_pn': 'mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Futilities%2F',
    '_chartbeat2': '.1649184641023.1649217725226.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.151',
    '_chartbeat5': '',
    'OptanonConsent': 'isGpcEnabled=0&datestamp=Tue+Apr+05+2022+23%3A02%3A05+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false',
    's_sq': 'aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Futilities%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

headers = {
    'authority': 'money.cnn.com',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'sec-fetch-dest': 'document',
    'referer': 'https://money.cnn.com/data/sectors/utilities/',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'FastAB=0=5002,1=2669,2=1124,3=9614,4=5444,5=8402,6=0860,7=6835,8=5350,9=2537; optimizelyEndUserId=oeu1649184640328r0.43775867948414793; s_fid=5BCCF7323793C18F-1BD742756E695FD7; s_vi=[CS]v1|312647C03DF425C7-600015A68402DFBD[CE]; ugs=1; ug=624c8f800c13ae0a3f9083001668f38c; _cb_ls=1; _cb=iBns8jK6arBV-EqQ; OB-USER-TOKEN=2774002a-017f-448d-ae97-74d4b9d8f531; _pbjs_userid_consent_data=3524755945110770; __qca=P0-1079014940-1649184641582; OptanonControl=ccc=US&csc=IL&cic=0&otvers=6.26.0&pctm=0&reg=ccpa&ustcs=1YNN&vers=3.1.5; __gads=ID=32760c3c744b7017:T=1649184641:S=ALNI_Ma6-m6YjDekujmaxy552LeAkAtmLA; _fbp=fb.1.1649184642929.1834398661; umto=1; _hjSessionUser_1466492=eyJpZCI6IjMyYTk0NzZkLTQyMDctNWQ4Zi05ZDJhLTViODU4ZmM5MTQxNiIsImNyZWF0ZWQiOjE2NDkxODQ2OTIwNTUsImV4aXN0aW5nIjpmYWxzZX0=; hkgc=09e4e1b4-2604-11ec-89a9-151a31250201; zwmc=2127012215019385808; goiz=ee0eb4b92f9848deb2f252c26b5c9957; ifyr=KSWOJMV8-2-A4FJ; bea4=c082_7017581334479357558; WMUKID_STABLE=bb073be7-ea8f-4daa-af4e-cfa95e4a17b3; CDPID={"cdpId":"75135f3c-8eb9-4c8e-a9fb-3a297058fa37","wmukId":"bb073be7-ea8f-4daa-af4e-cfa95e4a17b3"}; sendAuthToken=true; sendHHID=false; isInHHIDExperiment=false; isInAuthTokenExperiment=true; sendWMSegs=false; idrTimestamp=%222022-04-05T18%3A51%3A33.043Z%22; _admrla=2.2-aa729c3311d0dece-69863af6-b511-11ec-8cc0-0bd6bf40dd59; _pubcid=87e0a039-f67a-4951-a2ab-8c835654b82b; AMCV_7FF852E2556756057F000101%40AdobeOrg=-1124106680%7CMCAID%7C312647C03DF425C7-600015A68402DFBD%7CMCIDTS%7C19088%7CMCMID%7C13303509423986652164353656063335438129%7CMCAAMLH-1649793980%7C7%7CMCAAMB-1649793980%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1649196380s%7CNONE%7CvVersion%7C5.2.0; btIdentify=5c2177a0-13c1-4ef9-a966-505a7c335368; last5stocks=SHEN%2BGOOG%2BAAPL%2BGE%2BF%2BC; _ga=GA1.2.30076962.1649189309; _gid=GA1.2.1179730247.1649189309; SelectedEdition=www; countryCode=US; stateCode=IL; geoData=urbana|IL|61801|US|NA|-500|broadband|40.120|-88.220; usprivacy=1YNN; s_cc=true; _sp_ses.f5fb=*; _bti=%7B%22app_id%22%3A%22cnn%22%2C%22bsin%22%3A%22s7SCPe9poRB55yzNwmE7UPJBQr%2FlnpngpIn8bd4Hk2FTFeAx1iK81MUubohvr%2BaJ%2BwwaHYG31DzqLwgJ4c%2BLCQ%3D%3D%22%2C%22is_identified%22%3Afalse%7D; psmSessionId=3373055f-4b72-4860-9599-12fcbecb0dc8; psmSessionStart=2022-04-06T02%3A12%3A08.365Z; psmPageLoadId=1; _awl=2.1649211128.0.5-71e02e464a80f1cb5c6b9c7de9337347-6763652d75732d63656e7472616c31-0; psmLastActiveTimestamp=2022-04-06T02%3A12%3A10.509Z; _cb_svref=null; __gpi=UID=0000043726df5568:T=1649189300:RT=1649211157:S=ALNI_MbufqO6AjZlHMJnN8vcTS8THPsM3g; session_depth=money.cnn.com%3D2%7C176917733%3D2; mnjs_session_depth=2%7C1649217065983; cto_bundle=umwQu19FVXRlcVIxZnJabThIeFRQVjYxck1KM3lPRDBqYW5QJTJCd0JPYndwZDEyM09PTDA3UDNrT09qOVZyRGIwTElWRFc3TU5jZnJTOXduWU5lWjhzdyUyRkRyZU9tbFh6cGtEN29WU3hQUmxDN2pmTVA2cDYlMkIzUzZFJTJCaUczRURtOWowbDBDNVFRamdZSiUyQkhnR3hXdUhubW9QUkp3JTNEJTNE; _sp_id.f5fb=1d92e30b-dda2-4335-a812-798a098d7377.1649184643.5.1649217723.1649204824.6a425a20-5f11-4fbf-8d84-7bcca9c36655; cnprevpage_pn=mny%3Ao%3Amoney%3A%2Fdata%2Fsectors%2Futilities%2F; _chartbeat2=.1649184641023.1649217725226.1.BO-XsnB6WWR6CzjL43BWrXoDOXBLE.151; _chartbeat5=; OptanonConsent=isGpcEnabled=0&datestamp=Tue+Apr+05+2022+23%3A02%3A05+GMT-0500+(%E5%8C%97%E7%BE%8E%E4%B8%AD%E9%83%A8%E5%A4%8F%E4%BB%A4%E6%97%B6%E9%97%B4)&version=6.26.0&isIABGlobal=false&hosts=&consentId=45c44c27-5b98-478b-949a-3675c1e0ebff&interactionCount=1&landingPath=NotLandingPage&groups=BG173%3A1%2Csmv%3A1%2Cpfv%3A1%2Cpzv%3A1%2Cven%3A1%2Csav%3A1%2Cpf%3A1%2Cpz%3A1%2Csa%3A1%2Cad%3A1%2Csm%3A1%2Ctdc%3A1%2Ccos%3A1%2Cdid%3A1%2Cdlk%3A1%2Cpcp%3A1%2Cdsa%3A1%2Cmra%3A1%2Cmap%3A1%2Cpap%3A1%2Cgld%3A1%2Cpad%3A1%2Cpdd%3A1%2Csid%3A1%2Ccad%3A1%2Csec%3A1%2Cai%3A1%2Cfc%3A1%2Ctc%3A1%2Cpcd%3A1%2Cmcp%3A1%2Creq%3A1&AwaitingReconsent=false; s_sq=aolturnercnnmoney-2010%3D%2526pid%253Dmny%25253Ao%25253Amoney%25253A%25252Fdata%25252Fsectors%25252Futilities%25252F%2526pidt%253D1%2526oid%253Dfunctiononclick%252528event%252529%25257Bcommon.updateQueryString%252528%252527page%252527%25252C2%252529%25253B%25257D%2526oidt%253D2%2526ot%253DSPAN',
}

params = {
    'page': '2',
}

response = requests.get('https://money.cnn.com/data/sectors/utilities/?page=2', headers=headers, params=params, cookies=cookies)
fo = open("./utilities.txt", 'a', encoding = "utf-8")
response.encoding = 'utf-8'
soup = BeautifulSoup(response.text, 'html.parser')
content = "#wsod_companiesInIndustry > tbody > tr > td "
a = soup.select(content)
for i in range(0,len(a)):
    a[i] = a[i].text
    fo.write(a[i] + '\n')
fo.close()


















