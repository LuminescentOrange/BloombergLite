import sys
import pandas as pd
result = []
with open('communications.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./cummunications.csv',encoding='utf-8-sig')


result = []
with open('consumer durables.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./consumer durables.csv',encoding='utf-8-sig')		


result = []
with open('consumer non-durables.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./consumer non-durables.csv',encoding='utf-8-sig')	


result = []
with open('commercial service.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./commercial service.csv',encoding='utf-8-sig')	


result = []
with open('electronic technology.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./electronic technology.csv',encoding='utf-8-sig')	


result = []
with open('energy minerals.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./energy minerals.csv',encoding='utf-8-sig')	


result = []
with open('finance.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./finance.csv',encoding='utf-8-sig')	


result = []
with open('health service.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./health service.csv',encoding='utf-8-sig')	


result = []
with open('retail trade.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./retail trade.csv',encoding='utf-8-sig')	


result = []
with open('technology service.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./technology service.csv',encoding='utf-8-sig')	


result = []
with open('transportation.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./transportation.csv',encoding='utf-8-sig')	


result = []
with open('utilities.txt','r',encoding = 'utf-8') as f:
    text = f.readlines()
    for line in text:
        result.append(line.strip('\n'))
###### data  all in list
step = 7
b = [result[i:i+step] for i in range(0,len(result),step)] ###每集个数据放在一起
name=['Company','Market cap','P/E','Price','Change','% Change', 'YTD change']
df=pd.DataFrame(columns=name,data=b)
df.to_csv('./utilities.csv',encoding='utf-8-sig')	












